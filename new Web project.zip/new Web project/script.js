document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("Day1").addEventListener("click", function() {
      window.location.href = "./pages.html/day1.html";
    });
  });

  document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("Day2").addEventListener("click", function() {
      window.location.href = "./pages.html/day2.html";
    });
  });

  document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("Day3").addEventListener("click", function() {
      window.location.href = "./pages.html/day3.html";
    });
  });
  document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("Day4").addEventListener("click", function() {
      window.location.href = "./pages.html/day4.html";
    });
  });




